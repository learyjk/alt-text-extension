(()=>{var t=n=>Object.keys(n)[0],e=n=>n?!0:(console.info("element not found: ",t({element:n})),!1);})();
